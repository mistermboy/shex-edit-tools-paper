# ShExAuthor
<img src="https://img.shields.io/badge/work-inProgress-green" alt="size"/>

ShExAuthor is a  [Shape Expressions (ShEx)](http://shex.io/) graphic assistant where users can create their Shapes in a much more visual way.
In combination with [YASHE](https://github.com/weso/YASHE) editor, ShExAuthor allows you to use the editor and the assistant at the same time.


<h2 align="center">Create a Shape using the assistant</h2>
<p align="center">
  <img src="./public/finalCreateShape.gif"  alt="ShExAuthor GIF"/>
</p>

<h2 align="center">Visualize a Shape on the assistant</h2>
<p align="center">
  <img src="./public/finalShapeRecognition.gif"  alt="ShExAuthor GIF"/>
</p>

