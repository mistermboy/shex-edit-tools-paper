export const DEFAULTS = {
    sincronize:true,
    pretty:'pretty2',
    saveColors:true,
}