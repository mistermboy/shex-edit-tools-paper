import Type from '../../type';

class BNodeKind extends Type{

    getTypeName(){
        return 'bnode';
    }

    toString(){
        return 'BNODE';
    }



}

export default BNodeKind;