class CardinalitySimple{

    constructor(value=' '){
        this.value = value;
    }

    getCardType(){
        return this.value;
    }

    toString(){
        return this.value;
    }

}

export default CardinalitySimple;