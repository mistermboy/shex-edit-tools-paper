module.exports = {
  style: ["src/scss/scoped.scss", "src/scss/global.scss"],
  bundleDir: "dist",
  bundleFileName: "yashe",
  docDir: "doc"
};
