#!/bin/bash
"C:\Program Files\swipl\bin\swipl.exe"  -s util/gen_shex11.pl -t go

