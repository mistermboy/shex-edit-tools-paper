#!/bin/bash
swipl -s util/gen_shex11.pl -t go

